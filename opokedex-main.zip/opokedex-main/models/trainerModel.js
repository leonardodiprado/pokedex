// models/trainerModel.js
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('postgres://postgres:8942@localhost:5432/pokedex'); // Atualize com suas credenciais

const Trainer = sequelize.define('Trainer', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    pokemons: {
        type: DataTypes.JSON, // Podemos usar JSON para armazenar a lista de Pokémons
        allowNull: true,
    },
});

module.exports = { Trainer, sequelize };
