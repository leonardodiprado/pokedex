// controllers/trainerController.js
const { Trainer } = require('../models/trainerModel');
const { getPokemons } = require('../models/pokemonModel');

// Função para exibir a lista de treinadores
async function listTrainers(req, res) {
    try {
        const trainers = await Trainer.findAll();
        res.render('trainerIndex', { trainers });
    } catch (error) {
        res.status(500).send('Erro ao listar treinadores');
    }
}

// Função para renderizar o formulário de criação de treinador
function showCreateForm(req, res) {
    const pokemons = getPokemons(); // Pegar os Pokémons da model
    res.render('createTrainer', { pokemons });
}

// Função para criar um novo treinador
async function createTrainer(req, res) {
    const { name, selectedPokemons } = req.body;
    const trainerPokemons = getPokemons().filter(pokemon => selectedPokemons.includes(pokemon.id.toString()));
    try {
        await Trainer.create({ name, pokemons: trainerPokemons });
        res.redirect('/trainers');
    } catch (error) {
        res.status(500).send('Erro ao criar treinador');
    }
}

module.exports = {
    listTrainers,
    showCreateForm,
    createTrainer
};
